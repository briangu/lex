// readrawdata.cpp - rebuilds the dictionary from original data

#include "common.h"


void LoadRawDictionary()
{    
	printf("Raw dictionary code not installed\r\n");
}
void ReadTaggerPos(char* file)
{
}
void ReadBrown(char* file)
{
}
void ReadMedpost(char* file)
{
}
void ReadANC(char* file)
{
}
